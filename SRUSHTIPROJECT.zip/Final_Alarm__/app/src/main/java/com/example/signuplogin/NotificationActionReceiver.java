package com.example.signuplogin;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class NotificationActionReceiver extends BroadcastReceiver {

    private static final String TAG = "NotificationActionReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) {
            Log.e(TAG, "Received null intent or action");
            return;
        }

        String action = intent.getAction();
        String medicineName = intent.getStringExtra("medicine_name");
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Calendar.getInstance().getTime());

        if (medicineName == null) {
            Log.e(TAG, "Medicine name is null!");
            return;
        }

        if ("YES_ACTION".equals(action)) {
            storeResponseInFirebase(context, medicineName, "Yes", timestamp);
        } else if ("NO_ACTION".equals(action)) {
            storeResponseInFirebase(context, medicineName, "No", timestamp);
        } else if ("SNOOZE_ACTION".equals(action)) {
            storeResponseInFirebase(context, medicineName, "Snooze", timestamp);
            snoozeAlarm(context, medicineName);
        }
    }

    private void storeResponseInFirebase(Context context, String medicineName, String response, String timestamp) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Tracker");
        String key = databaseReference.push().getKey();

        if (key != null) {
            Map<String, Object> data = new HashMap<>();
            data.put("medicineName", medicineName);
            data.put("response", response);
            data.put("timestamp", timestamp);

            databaseReference.child(key).setValue(data)
                    .addOnSuccessListener(aVoid -> Log.d(TAG, "Response stored successfully: " + response))
                    .addOnFailureListener(e -> Log.e(TAG, "Failed to store response", e));
        }
    }

    private void snoozeAlarm(Context context, String medicineName) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent alarmIntent = new Intent(context, AlarmReceiver.class);
        alarmIntent.putExtra("medicine_name", medicineName);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, Objects.hash(medicineName), alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, 10);

        if (alarmManager != null) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
            Toast.makeText(context, "Snoozed for 10 minutes", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Alarm snoozed for 10 minutes for: " + medicineName);
        } else {
            Log.e(TAG, "AlarmManager is null, cannot snooze alarm");
        }
    }
}
