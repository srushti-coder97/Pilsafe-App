package com.example.signuplogin;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FeedbackFragment extends Fragment {

    private EditText feedbackText;
    private RatingBar ratingBar;
    private Button btnSubmitFeedback;
    private TextView tvFeedbackTime, tvFeedbackRating;
    private DatabaseReference feedbackRef;

    public FeedbackFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_feedback, container, false);

        feedbackText = view.findViewById(R.id.etFeedback);
        ratingBar = view.findViewById(R.id.ratingBar);
        btnSubmitFeedback = view.findViewById(R.id.btnSubmitFeedback);
        tvFeedbackTime = view.findViewById(R.id.tvFeedbackTime);
        tvFeedbackRating = view.findViewById(R.id.tvRatingLabel);

        // Initialize Firebase reference
        feedbackRef = FirebaseDatabase.getInstance().getReference("Feedback");

        btnSubmitFeedback.setOnClickListener(v -> submitFeedback());

        ratingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) ->
                tvFeedbackRating.setText(getString(R.string.rating_label, rating))
        );

        updateSubmissionTime();

        return view;
    }

    private void submitFeedback() {
        String feedbackMessage = feedbackText.getText().toString().trim();
        float ratingValue = ratingBar.getRating();
        String submittedDate = getCurrentTime();

        if (TextUtils.isEmpty(feedbackMessage)) {
            feedbackText.setError("Please enter your feedback");
            return;
        }
        if (ratingValue == 0) {
            Toast.makeText(getContext(), "Please give a rating", Toast.LENGTH_SHORT).show();
            return;
        }

        String feedbackId = feedbackRef.push().getKey();
        if (feedbackId == null) {
            Toast.makeText(getContext(), "Error generating feedback ID", Toast.LENGTH_SHORT).show();
            return;
        }

        FeedbackModel feedback = new FeedbackModel(feedbackId, feedbackMessage, ratingValue, submittedDate);
        feedbackRef.child(feedbackId).setValue(feedback)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Feedback submitted successfully!", Toast.LENGTH_SHORT).show();
                    resetFields();
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to submit feedback", Toast.LENGTH_SHORT).show());
    }

    private void resetFields() {
        feedbackText.setText("");
        ratingBar.setRating(0);
        updateSubmissionTime();
    }

    private void updateSubmissionTime() {
        tvFeedbackTime.setText(getString(R.string.submitted_on, getCurrentTime()));
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }
}
