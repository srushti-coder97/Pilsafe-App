
package com.example.signuplogin;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FeedbackActivity extends AppCompatActivity {

    private TextView tvFeedbackTime, tvFeedbackRating;
    private RatingBar ratingBar;
    private EditText feedbackText;
    private Button btnSubmitFeedback;
    private DatabaseReference feedbackDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        // Initialize Firebase Database reference
        feedbackDatabase = FirebaseDatabase.getInstance().getReference("Feedback");

        // Initialize UI components
        tvFeedbackTime = findViewById(R.id.tvFeedbackTime); // ✅ Ensure this exists in XML
        tvFeedbackRating = findViewById(R.id.tvRatingLabel);
        ratingBar = findViewById(R.id.ratingBar);
        feedbackText = findViewById(R.id.etFeedback);
        btnSubmitFeedback = findViewById(R.id.btnSubmitFeedback);

        // Display the current time
        updateSubmissionTime();

        // Update rating label dynamically
        ratingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) ->
                tvFeedbackRating.setText("Rating: " + rating)
        );

        // Submit feedback when the button is clicked
        btnSubmitFeedback.setOnClickListener(v-> submitFeedback()
        );
    }

    private void submitFeedback() {
        String feedbackMessage = feedbackText.getText().toString().trim();
        float ratingValue = ratingBar.getRating();
        String submittedDate = getCurrentTime();

        // Validation
        if (TextUtils.isEmpty(feedbackMessage)) {
            feedbackText.setError("Please enter your feedback");
            return;
        }
        if (ratingValue == 0) {
            Toast.makeText(this, "Please give a rating", Toast.LENGTH_SHORT).show();
            return;
        }

        // Generate unique ID for feedback
        String feedbackId = feedbackDatabase.push().getKey();
        if (feedbackId == null) {
            Toast.makeText(this, "Error generating feedback ID", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create feedback object
        FeedbackModel feedback = new FeedbackModel(feedbackId, feedbackMessage, ratingValue, submittedDate);

        // Save feedback to Firebase
        feedbackDatabase.child(feedbackId).setValue(feedback)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(FeedbackActivity.this, "Feedback submitted successfully!", Toast.LENGTH_SHORT).show();
                    resetFields();
                })
                .addOnFailureListener(e -> Toast.makeText(FeedbackActivity.this, "Failed to submit feedback", Toast.LENGTH_SHORT).show());
    }

    private void resetFields() {
        feedbackText.setText("");  // Clear input
        ratingBar.setRating(0);    // Reset rating
        updateSubmissionTime();    // Update submission time
    }

    private void updateSubmissionTime() {
        tvFeedbackTime.setText("Submitted on: " + getCurrentTime());
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }
}