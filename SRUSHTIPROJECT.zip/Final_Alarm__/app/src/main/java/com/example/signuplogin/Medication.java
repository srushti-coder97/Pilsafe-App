package com.example.signuplogin;

public class Medication {
    private String id;
    private String medicineName;
    private String response;
    private String timestamp;

    // Required empty constructor for Firebase
    public Medication() {
    }

    public Medication(String id, String medicineName, String response, String timestamp) {
        this.id = id;
        this.medicineName = medicineName;
        this.response = response;
        this.timestamp = timestamp;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public String getResponse() {
        return response;
    }

    public String getTimestamp() {
        return timestamp;
    }

    // Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}

