package com.example.signuplogin;

public class User {
    public String userId;
    public String email;
    public String name;
    public String age;
    public String birthdate;
    public String contact;
    public String bloodGroup;
    public String gender;

    // Default constructor (Required for Firebase)
    public User() {
    }

    // Constructor with only userId and email
    public User(String userId, String email) {
        this.userId = userId;
        this.email = email;
    }

    // Constructor with all user details (for full profile)
    public User(String userId, String email, String name, String age, String birthdate, String contact, String bloodGroup, String gender) {
        this.userId = userId;
        this.email = email;
        this.name = name;
        this.age = age;
        this.birthdate = birthdate;
        this.contact = contact;
        this.bloodGroup = bloodGroup;
        this.gender = gender;
    }
}
