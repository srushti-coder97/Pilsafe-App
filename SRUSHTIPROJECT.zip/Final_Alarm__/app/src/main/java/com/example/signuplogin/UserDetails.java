package com.example.signuplogin;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class UserDetails extends AppCompatActivity {

    EditText user_Name, user_Age, user_Bdate, user_contact, user_bloodGroup;
    RadioGroup rgGender;
    RadioButton rbMale, rbFemale;
    Button btnSave;
    String[] bloodGroups = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};

    private DatabaseReference databaseReference;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_details);

        // Initialize Firebase
        auth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        // Initialize Views
        user_Name = findViewById(R.id.user_Name);
        user_Age = findViewById(R.id.user_Age);
        user_Bdate = findViewById(R.id.user_Bdate);
        user_contact = findViewById(R.id.user_contact);
        user_bloodGroup = findViewById(R.id.user_bloodGroup);
        rgGender = findViewById(R.id.rgGender);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        btnSave = findViewById(R.id.btnSave);

        // Calendar Picker for Birthdate
        user_Bdate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(UserDetails.this, (view, selectedYear, selectedMonth, selectedDay) -> {
                selectedMonth = selectedMonth + 1; // Month starts from 0
                String birthdate = selectedDay + "/" + selectedMonth + "/" + selectedYear;
                user_Bdate.setText(birthdate);
            }, year, month, day);
            datePickerDialog.show();
        });

        // Blood Group Selection
        user_bloodGroup.setOnClickListener(v -> {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(UserDetails.this);
            builder.setTitle("Select Blood Group");
            builder.setItems(bloodGroups, (dialog, which) -> user_bloodGroup.setText(bloodGroups[which]));
            builder.show();
        });

        // Save Button Click
        btnSave.setOnClickListener(v -> saveUserData());
    }

    private void saveUserData() {
        String name = user_Name.getText().toString();
        String age = user_Age.getText().toString();
        String bdate = user_Bdate.getText().toString();
        String contact = user_contact.getText().toString();
        String bloodGroup = user_bloodGroup.getText().toString();
        String gender = rbMale.isChecked() ? "Male" : rbFemale.isChecked() ? "Female" : "Not Selected";

        if (name.isEmpty() || age.isEmpty() || bdate.isEmpty() || contact.isEmpty() || bloodGroup.isEmpty()) {
            Toast.makeText(UserDetails.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            String email = currentUser.getEmail();

            // Create User object with additional details
            User user = new User(userId, email, name, age, bdate, contact, bloodGroup, gender);

            // Save user data in Firebase Realtime Database
            databaseReference.child(userId).setValue(user).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(UserDetails.this, "User Details Saved Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(UserDetails.this, Dashboard.class));
                    finish();
                } else {
                    Toast.makeText(UserDetails.this, "Failed to save user details: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(UserDetails.this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }
}
