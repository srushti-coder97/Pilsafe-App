package com.example.signuplogin;

public class Note {
    private String noteId;
    private String feeling;
    private String description;
    private String time;
    private long timestamp; // Added timestamp field for sorting

    // Default constructor required for Firebase
    public Note() {
    }

    public Note(String noteId, String feeling, String description, String time, long timestamp) {
        this.noteId = noteId;
        this.feeling = feeling;
        this.description = description;
        this.time = time;
        this.timestamp = timestamp;
    }

    // Getters and Setters
    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }

    public String getFeeling() {
        return feeling;
    }

    public void setFeeling(String feeling) {
        this.feeling = feeling;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
