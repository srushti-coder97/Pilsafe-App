package com.example.signuplogin;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class AddMedicineActivity extends AppCompatActivity {

    private EditText medication_name, descriptionEditText;
    private Spinner medicineShapeSpinner, scheduleSpinner;
    private RadioGroup reminder_type_group;
    private TextView reminder_times_text;
    private Button add_time_button, s_btn;
    private List<String> reminderTimesList = new ArrayList<>();
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        requestNotificationPermission();
        requestAlarmPermission();

        medication_name = findViewById(R.id.medication_name);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        medicineShapeSpinner = findViewById(R.id.medicine_shape_spinner);
        scheduleSpinner = findViewById(R.id.schedule_spinner);
        reminder_type_group = findViewById(R.id.reminder_type_group);
        reminder_times_text = findViewById(R.id.reminder_times_text);
        add_time_button = findViewById(R.id.add_time_button);
        s_btn = findViewById(R.id.s_btn);

        databaseReference = FirebaseDatabase.getInstance().getReference("Medicines");
        setupSpinners();
        add_time_button.setOnClickListener(v -> openTimePicker());
        s_btn.setOnClickListener(v -> saveMedicineData());
    }

    private void setupSpinners() {
        String[] medicineShapes = {"Tablet", "Capsule", "Syrup", "Drop", "Liquid"};
        ArrayAdapter<String> shapeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, medicineShapes);
        shapeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        medicineShapeSpinner.setAdapter(shapeAdapter);

        String[] medicineSchedules = {"Daily", "Weekly", "Monthly"};
        ArrayAdapter<String> scheduleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, medicineSchedules);
        scheduleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        scheduleSpinner.setAdapter(scheduleAdapter);
    }

    private void openTimePicker() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            String time = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
            reminderTimesList.add(time);
            updateReminderTimesDisplay();
        }, hour, minute, true);
        timePickerDialog.show();
    }

    private void updateReminderTimesDisplay() {
        reminder_times_text.setText(reminderTimesList.isEmpty() ? "No times added" : "Reminder Time(s): " + String.join(", ", reminderTimesList));
    }

    private void saveMedicineData() {
        String medicineName = medication_name.getText().toString().trim();
        if (medicineName.isEmpty() || reminderTimesList.isEmpty()) {
            Toast.makeText(this, "Enter medicine name and at least one reminder time", Toast.LENGTH_SHORT).show();
            return;
        }

        String medicineId = databaseReference.push().getKey();
        Medicine medicine = new Medicine(medicineId, medicineName, descriptionEditText.getText().toString().trim(),
                medicineShapeSpinner.getSelectedItem().toString(), scheduleSpinner.getSelectedItem().toString(),
                ((RadioButton) findViewById(reminder_type_group.getCheckedRadioButtonId())).getText().toString(),
                reminderTimesList, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));

        if (medicineId != null) {
            databaseReference.child(medicineId).setValue(medicine).addOnSuccessListener(aVoid -> {
                Toast.makeText(this, "Medicine added successfully!", Toast.LENGTH_SHORT).show();
                for (String time : reminderTimesList) setMedicineReminder(medicineName, time);
            }).addOnFailureListener(e -> Toast.makeText(this, "Failed to add medicine", Toast.LENGTH_SHORT).show());
        }
    }

    private void setMedicineReminder(String medicineName, String time) {
        Log.d("AlarmDebug", "setMedicineReminder() called for " + medicineName + " at " + time);


        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("medicine_name", medicineName);

        // Create unique request code based on medicine name and time
        int requestCode = (medicineName + time).hashCode();

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Parse time
        String[] timeParts = time.split(":");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeParts[0]));
        calendar.set(Calendar.MINUTE, Integer.parseInt(timeParts[1]));
        calendar.set(Calendar.SECOND, 0);


        Log.d("AlarmDebug", "Current time: " + System.currentTimeMillis());
        Log.d("AlarmDebug", "Scheduled alarm time: " + calendar.getTimeInMillis());

        // If time has passed today, schedule for tomorrow
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            Log.d("AlarmDebug", "Time already passed. Scheduling for next day at: " + calendar.getTimeInMillis());
        }

        // Schedule exact alarm
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis(),
                        pendingIntent
                );
                Log.d("AlarmDebug", "Exact alarm scheduled successfully.");
                Toast.makeText(this, "Reminder set for " + time, Toast.LENGTH_SHORT).show();
            } else {
                Log.d("AlarmDebug", "Exact alarm permission not granted.");
                Intent intent2 = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                startActivity(intent2);
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            );
            Log.d("AlarmDebug", "Alarm scheduled successfully.");
            Toast.makeText(this, "Reminder set for " + time, Toast.LENGTH_SHORT).show();
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void requestAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && ContextCompat.checkSelfPermission(this, android.Manifest.permission.SET_ALARM) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SET_ALARM}, 2);
        }
    }
}