package com.example.signuplogin;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.app.AlarmManager;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.navigation.NavigationView;

public class Dashboard extends AppCompatActivity {

    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dasboard);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!getSystemService(AlarmManager.class).canScheduleExactAlarms()) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                startActivity(intent);
            }
        }
        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Request Notification Permission for Android 13+
        requestNotificationPermission();

        // Open Navigation Drawer
        buttonDrawerToggle.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        // Handle Navigation Drawer Clicks
        navigationView.setNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.navsettings) {
                replaceFragment(new settings());
            } else if (itemId == R.id.navhistory) { // Add History Option
                replaceFragment(new HistoryFragment());
            } else if (itemId == R.id.navprofile) {
                Intent intent = new Intent(Dashboard.this, ProfilePage.class);
                startActivity(intent);
            } else if (itemId == R.id.navfeedback) {
                Intent intent = new Intent(Dashboard.this, FeedbackActivity.class);
                startActivity(intent);
            }

            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        // Handle Bottom Navigation Clicks
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.navigation_today) {
                replaceFragment(new TodayFragment());
                return true;
            } else if (itemId == R.id.navigation_add) { // Check if "Add" icon is clicked
                showAddOptionsDialog(); // Show options
                return true;
            } else if (itemId == R.id.navigation_medications) {
                replaceFragment(new MedicationsFragment()); // Add Medications Fragment
                return true;
            }

            return false;
        });

        // Set Default Fragment (e.g., Today Fragment)
        if (savedInstanceState == null) {
            replaceFragment(new TodayFragment());
        }
    }

    // Replace Fragment Function
    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.commit();
    }

    // Show Dialog to Choose Between "Add Medicine" and "Add Note"
    private void showAddOptionsDialog() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Choose an option")
                .setItems(new String[]{"Add Medicine", "Add Note"}, (dialog, which) -> {
                    if (which == 0) {
                        Log.d("Dashboard", "Opening AddMedicineActivity");
                        startActivity(new Intent(Dashboard.this, AddMedicineActivity.class));
                    } else if (which == 1) {
                        Intent intent = new Intent(Dashboard.this, AddNoteActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Fix to prevent activity issues
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    // Request notification permission for Android 13+
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }
    }
}