package com.example.signuplogin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfilePage extends AppCompatActivity {

    private TextView nameTextView, emailTextView, phoneTextView, genderTextView, birthdateTextView, bloodGroupTextView, ageTextView;
    private ImageView profileImageView;
    private Button editProfileButton, logoutButton;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        // Initialize Firebase Authentication
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String userId = user.getUid();
        userRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Initialize UI Elements
        nameTextView = findViewById(R.id.nameTextView);
        emailTextView = findViewById(R.id.emailTextView);
        phoneTextView = findViewById(R.id.phoneTextView);
        genderTextView = findViewById(R.id.genderTextView);
        birthdateTextView = findViewById(R.id.birthdateTextView);
        bloodGroupTextView = findViewById(R.id.bloodGroupTextView);
        ageTextView = findViewById(R.id.ageTextView);
        profileImageView = findViewById(R.id.profileImageView);
        editProfileButton = findViewById(R.id.editProfileButton);
        logoutButton = findViewById(R.id.logoutButton);

        // Load user profile data
        loadUserProfile();

        // Edit Profile Button Click Listener
        if (editProfileButton != null) {
            editProfileButton.setOnClickListener(v -> {
                Toast.makeText(ProfilePage.this, "Edit Profile Clicked!", Toast.LENGTH_SHORT).show(); // Debugging
                Intent intent = new Intent(ProfilePage.this, UserDetails.class);
                startActivity(intent);
            });
        } else {
            Toast.makeText(this, "Error: Edit Profile Button not found!", Toast.LENGTH_SHORT).show();
        }

        // Logout Button Click Listener
        if (logoutButton != null) {
            logoutButton.setOnClickListener(v -> {
                mAuth.signOut();
                Toast.makeText(ProfilePage.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ProfilePage.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            });
        } else {
            Toast.makeText(this, "Error: Logout Button not found!", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadUserProfile() {
        if (userRef != null) {
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String name = snapshot.child("name").getValue(String.class);
                        String email = snapshot.child("email").getValue(String.class);
                        String phone = snapshot.child("phone").getValue(String.class);
                        String gender = snapshot.child("gender").getValue(String.class);
                        String birthdate = snapshot.child("birthdate").getValue(String.class);
                        String bloodGroup = snapshot.child("bloodGroup").getValue(String.class);
                        String age = snapshot.child("age").getValue(String.class);

                        nameTextView.setText(name != null ? name : "N/A");
                        emailTextView.setText(email != null ? email : "N/A");
                        phoneTextView.setText(phone != null ? phone : "N/A");
                        genderTextView.setText(gender != null ? gender : "N/A");
                        birthdateTextView.setText(birthdate != null ? birthdate : "N/A");
                        bloodGroupTextView.setText(bloodGroup != null ? bloodGroup : "N/A");
                        ageTextView.setText(age != null ? age : "N/A");
                    } else {
                        Toast.makeText(ProfilePage.this, "No profile data found", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(ProfilePage.this, "Failed to load profile", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserProfile(); // Reload user details when returning from EditProfileActivity
    }
}