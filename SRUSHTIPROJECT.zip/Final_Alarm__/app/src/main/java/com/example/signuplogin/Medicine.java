package com.example.signuplogin;

import java.util.List;

public class Medicine {
    private String medicineId, name, description, shape, schedule, reminderType, dateAdded;
    private List<String> reminderTimes;

    public Medicine() { } // Required for Firebase

    public Medicine(String medicineId, String name, String description, String shape, String schedule,
                    String reminderType, List<String> reminderTimes, String dateAdded) {
        this.medicineId = medicineId;
        this.name = name;
        this.description = description;
        this.shape = shape;
        this.schedule = schedule;
        this.reminderType = reminderType;
        this.reminderTimes = reminderTimes;
        this.dateAdded = dateAdded;
    }

    // Getter for medicineId (use getId for consistency)
    public String getId() {
        return medicineId;
    }

    public String getMedicineId() {
        return medicineId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getShape() {
        return shape;
    }

    public String getSchedule() {
        return schedule;
    }

    public String getReminderType() {
        return reminderType;
    }

    public List<String> getReminderTimes() {
        return reminderTimes != null ? reminderTimes : List.of(); // Avoid null values
    }

    public String getDateAdded() {
        return dateAdded;
    }

    // Setters (If modification is required)
    public void setMedicineId(String medicineId) {
        this.medicineId = medicineId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setShape(String shape) {
        this.shape = shape;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public void setReminderType(String reminderType) {
        this.reminderType = reminderType;
    }

    public void setReminderTimes(List<String> reminderTimes) {
        this.reminderTimes = reminderTimes;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }
}
