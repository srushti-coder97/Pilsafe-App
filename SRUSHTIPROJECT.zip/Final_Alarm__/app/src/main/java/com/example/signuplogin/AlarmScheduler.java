package com.example.signuplogin;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;

public class AlarmScheduler {

    // Schedule multiple alarms based on stored times
    public static void scheduleAlarms(Context context, AlarmModel alarmModel) {
        if (alarmModel.getReminderTimesList() == null || alarmModel.getReminderTimesList().isEmpty()) {
            Log.e("AlarmScheduler", "No reminder times set for " + alarmModel.getMedicineName());
            return;
        }

        for (String time : alarmModel.getReminderTimesList()) {
            scheduleAlarm(context, alarmModel.getMedicineName(), time);
        }
    }

    // Now this method is public so it can be accessed from NoReceiver and other classes
    public static void scheduleAlarm(Context context, String medicineName, String time) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.setAction("com.example.signuplogin.MEDICINE_ALARM");
        intent.putExtra("medicine_name", medicineName);

        // Unique request code for each alarm
        int requestCode = (medicineName + time).hashCode();

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Parse time
        String[] timeParts = time.split(":");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeParts[0]));
        calendar.set(Calendar.MINUTE, Integer.parseInt(timeParts[1]));
        calendar.set(Calendar.SECOND, 0);

        Log.d("AlarmScheduler", "Current time: " + System.currentTimeMillis());
        Log.d("AlarmScheduler", "Scheduled alarm time: " + calendar.getTimeInMillis());

        // If time has passed today, schedule for tomorrow
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            Log.d("AlarmScheduler", "Time already passed. Scheduling for next day at: " + calendar.getTimeInMillis());
        }

        scheduleExactAlarm(alarmManager, calendar, pendingIntent, context, time);
    }

    // New method to schedule alarms with delay (Used in NoReceiver when "No" is clicked)
    public static void scheduleAlarm(Context context, String medicineName, int delayMinutes) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.setAction("com.example.signuplogin.MEDICINE_ALARM");
        intent.putExtra("medicine_name", medicineName);

        int requestCode = (medicineName + delayMinutes).hashCode();
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, delayMinutes); // Set delay time

        Log.d("AlarmScheduler", "Scheduling alarm in " + delayMinutes + " minutes.");

        scheduleExactAlarm(alarmManager, calendar, pendingIntent, context, delayMinutes + " min");
    }

    // Common method to set exact alarm
    private static void scheduleExactAlarm(AlarmManager alarmManager, Calendar calendar, PendingIntent pendingIntent, Context context, String time) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                Log.d("AlarmScheduler", "Exact alarm scheduled successfully for " + time);
                Toast.makeText(context, "Reminder set for " + time, Toast.LENGTH_SHORT).show();
            } else {
                Log.d("AlarmScheduler", "Exact alarm permission not granted.");
                Toast.makeText(context, "Please grant exact alarm permission.", Toast.LENGTH_LONG).show();
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
            Log.d("AlarmScheduler", "Alarm scheduled successfully for " + time);
            Toast.makeText(context, "Reminder set for " + time, Toast.LENGTH_SHORT).show();
        }
    }
}
