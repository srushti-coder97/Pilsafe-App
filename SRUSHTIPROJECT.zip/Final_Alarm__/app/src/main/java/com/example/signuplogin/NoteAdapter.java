package com.example.signuplogin;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {
    private Context context;
    private List<Note> noteList;

    public NoteAdapter(Context context, List<Note> noteList) {
        this.context = context;
        this.noteList = noteList;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R .layout.item_note, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = noteList.get(position);

        holder.textViewFeeling.setText("Feeling: " + note.getFeeling());
        holder.textViewDescription.setText(note.getDescription());
        holder.textViewTime.setText("Time: " + note.getTime());

        // Delete Button Click Event
        holder.btnDeleteNote.setOnClickListener(v -> {
            if (note.getNoteId() != null) {
                DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("History").child(note.getNoteId());

                dbRef.removeValue().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        noteList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, noteList.size());
                    } else {
                        Log.e("NoteAdapter", "Failed to delete note: " + task.getException());
                    }
                });
            } else {
                Log.e("NoteAdapter", "Note ID is null, cannot delete.");
            }
        });
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView textViewFeeling, textViewDescription, textViewTime;
        ImageButton btnDeleteNote;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewFeeling = itemView.findViewById(R.id.textViewFeeling);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            textViewTime = itemView.findViewById(R.id.textViewTime);
            btnDeleteNote = itemView.findViewById(R.id.btnDeleteNote);
        }
    }
}
