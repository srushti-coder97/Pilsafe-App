package com.example.signuplogin;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;
import android.util.Log;

public class MedicationsFragment extends Fragment {
    private RecyclerView recyclerView;
    private MedicationAdapter adapter;
    private List<Medication> medicationList;
    private DatabaseReference databaseReference;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_medications, container, false);

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerViewMedications);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize medication list and adapter
        medicationList = new ArrayList<>();
        adapter = new MedicationAdapter(medicationList, getContext());
        recyclerView.setAdapter(adapter);

        // Fetch data from Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("Tracker");
        fetchMedicationData();

        return view;
    }

    // Fetch medication data from Firebase Realtime Database
    private void fetchMedicationData() {
        databaseReference.orderByChild("timestamp").limitToLast(10)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        medicationList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Medication medication = data.getValue(Medication.class);
                            if (medication != null) {
                                medication.setId(data.getKey());  // ✅ Set ID from Firebase Key
                                medicationList.add(medication);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("Firebase", "Failed to fetch medications", error.toException());
                    }
                });
    }
}