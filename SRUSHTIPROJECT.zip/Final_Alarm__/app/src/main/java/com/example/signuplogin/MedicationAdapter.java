package com.example.signuplogin;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class MedicationAdapter extends RecyclerView.Adapter<MedicationAdapter.ViewHolder> {
    private List<Medication> medicationList;
    private Context context;

    public MedicationAdapter(List<Medication> medicationList, Context context) {
        this.medicationList = medicationList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medication, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Medication medication = medicationList.get(position);
        holder.txtMedicineName.setText(medication.getMedicineName());
        holder.txtResponse.setText("Response: " + medication.getResponse());
        holder.txtTimestamp.setText("Time: " + medication.getTimestamp());

        // ✅ Delete button click listener
        holder.btnDelete.setOnClickListener(v -> {
            Log.d("MedicationAdapter", "Delete button clicked");

            if (medication.getId() == null || medication.getId().isEmpty()) {
                Toast.makeText(context, "Error: Medication ID is missing!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Reference to Firebase "Tracker" node
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Tracker")
                    .child(medication.getId());

            // ✅ Remove the medication from Firebase
            databaseReference.removeValue()
                    .addOnSuccessListener(aVoid -> {
                        Log.d("MedicationAdapter", "Delete success");
                        Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show();

                        // ✅ Remove from list and update UI
                        medicationList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, medicationList.size());
                    })
                    .addOnFailureListener(e -> {
                        Log.e("MedicationAdapter", "Delete failed", e);
                        Toast.makeText(context, "Failed to Delete", Toast.LENGTH_SHORT).show();
                    });
        });
    }

    @Override
    public int getItemCount() {
        return medicationList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtMedicineName, txtResponse, txtTimestamp;
        ImageButton btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtMedicineName = itemView.findViewById(R.id.txtMedicineName);
            txtResponse = itemView.findViewById(R.id.txtResponse);
            txtTimestamp = itemView.findViewById(R.id.txtTimestamp);
            btnDelete = itemView.findViewById(R.id.btnDeleteMedication);
        }
    }
}
