package com.example.signuplogin;

public class FeedbackModel {
    public String feedbackId;
    public String message;
    public float rating;
    public String date;

    // Default constructor (required for Firebase)
    public FeedbackModel() {
    }

    // Parameterized constructor
    public FeedbackModel(String feedbackId, String message, float rating, String date) {
        this.feedbackId = feedbackId;
        this.message = message;
        this.rating = rating;
        this.date = date;
    }

    // Getters and setters
    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
}
