package com.example.signuplogin;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HistoryFragment extends Fragment {
    private RecyclerView recyclerView;
    private NoteAdapter noteAdapter;
    private List<Note> noteList;
    private DatabaseReference databaseReference;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewHistory);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(requireContext(), noteList);
        recyclerView.setAdapter(noteAdapter);

        databaseReference = FirebaseDatabase.getInstance().getReference("History"); // Ensure "History" is the correct path
        fetchHistoryData();

        return view;
    }

    private void fetchHistoryData() {
        databaseReference.orderByChild("timestamp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                noteList.clear();
                List<Note> tempNoteList = new ArrayList<>();

                for (DataSnapshot data : snapshot.getChildren()) {
                    Note note = data.getValue(Note.class);
                    if (note != null) {
                        tempNoteList.add(note);
                    }
                }

                // Reverse the list so newest notes appear first
                Collections.reverse(tempNoteList);

                noteList.addAll(tempNoteList);
                noteAdapter.notifyDataSetChanged();

                Log.d("HistoryFragment", "Notes loaded: " + noteList.size());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("HistoryFragment", "Database error: " + error.getMessage());
            }
        });
    }
}
