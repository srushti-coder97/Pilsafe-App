package com.example.signuplogin;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class NoReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String medicineName = intent.getStringExtra("medicine_name");

        if (medicineName != null) {
            Log.d("NoReceiver", "Medicine not taken, rescheduling reminders...");

            // Schedule notifications in 10 and 20 minutes
            AlarmScheduler.scheduleAlarm(context, medicineName, 10);
            AlarmScheduler.scheduleAlarm(context, medicineName, 20);
        }
    }
}
