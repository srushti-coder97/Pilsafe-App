package com.example.signuplogin;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class AddNoteActivity extends AppCompatActivity {

    private EditText noteDescription;
    private TextView selectedTime;
    private Button saveNoteBtn;
    private String feeling = "Neutral"; // Default feeling

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        noteDescription = findViewById(R.id.note_description);
        selectedTime = findViewById(R.id.selected_time);
        saveNoteBtn = findViewById(R.id.save_note_btn);

        // Firebase Database Reference
        databaseReference = FirebaseDatabase.getInstance().getReference("History");

        // Handle Feeling Selection
        ImageButton feverButton = findViewById(R.id.feeling_good);
        ImageButton vomitingButton = findViewById(R.id.feeling_happy);
        ImageButton sickButton = findViewById(R.id.feeling_not_well);

        feverButton.setOnClickListener(v -> {
            feeling = "Fever";
            Toast.makeText(this, "Feeling: Fever", Toast.LENGTH_SHORT).show();
        });
        vomitingButton.setOnClickListener(v -> {
            feeling = "Vomiting";
            Toast.makeText(this, "Feeling: Vomiting", Toast.LENGTH_SHORT).show();
        });
        sickButton.setOnClickListener(v -> {
            feeling = "Sick";
            Toast.makeText(this, "Feeling: Sick", Toast.LENGTH_SHORT).show();
        });

        // Time Picker
        selectedTime.setOnClickListener(v -> showTimePicker());

        // Save Button Click
        saveNoteBtn.setOnClickListener(v -> saveNoteToFirebase());
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, hourOfDay, minute1) -> {
            String time = hourOfDay + ":" + String.format("%02d", minute1);
            selectedTime.setText(time);
        }, hour, minute, DateFormat.is24HourFormat(this));

        timePickerDialog.show();
    }

    private void saveNoteToFirebase() {
        String description = noteDescription.getText().toString().trim();
        String time = selectedTime.getText().toString();

        if (description.isEmpty()) {
            noteDescription.setError("Enter a note");
            return;
        }
        if (time.equals("Select Time")) {
            Toast.makeText(this, "Please select a time", Toast.LENGTH_SHORT).show();
            return;
        }

        String noteId = databaseReference.push().getKey(); // Generate unique ID
        Map<String, Object> noteData = new HashMap<>();
        noteData.put("id", noteId);
        noteData.put("feeling", feeling);
        noteData.put("description", description);
        noteData.put("time", time);

        databaseReference.child(noteId).setValue(noteData)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(AddNoteActivity.this, "Note Saved", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(AddNoteActivity.this, "Failed to save note", Toast.LENGTH_SHORT).show());
    }
}
