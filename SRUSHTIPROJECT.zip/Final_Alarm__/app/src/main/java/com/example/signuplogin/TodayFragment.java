package com.example.signuplogin;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TodayFragment extends Fragment {
    private DatabaseReference databaseReference;
    private List<Medicine> todayMedicines;
    private MedicineAdapter adapter;
    private RecyclerView recyclerView;

    public TodayFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_today, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        todayMedicines = new ArrayList<>();
        adapter = new MedicineAdapter(getContext(), todayMedicines);
        recyclerView.setAdapter(adapter);

        fetchTodayMedicines();

        return view;
    }

    private void fetchTodayMedicines() {
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        databaseReference = FirebaseDatabase.getInstance().getReference("Medicines");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                todayMedicines.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Medicine medicine = data.getValue(Medicine.class);
                    if (medicine != null) {
                        String medicineId = data.getKey(); // Get the unique ID of the medicine
                        String dateAdded = medicine.getDateAdded(); // Ensure this field exists in your Medicine class

                        if (dateAdded != null && todayDate.equals(dateAdded)) {
                            todayMedicines.add(medicine);
                            Log.d("TodayFragment", "Medicine added: " + medicine.getName() + " (ID: " + medicineId + ")");
                        }
                    }
                }
                Log.d("TodayFragment", "Total medicines for today: " + todayMedicines.size());
                adapter.notifyItemInserted(todayMedicines.size() - 1);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", "Error fetching medicines: " + error.getMessage());
                Toast.makeText(getContext(), "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
