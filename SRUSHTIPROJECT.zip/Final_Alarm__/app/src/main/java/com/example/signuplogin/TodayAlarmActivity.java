package com.example.signuplogin;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class TodayAlarmActivity extends AppCompatActivity {

    private ListView medicineListView;
    private DatabaseReference databaseReference;
    private String userId;
    private ArrayList<String> medicineList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_today_alarm); // Ensure correct XML file

        medicineListView = findViewById(R.id.medicineListView);
        medicineList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, medicineList);
        medicineListView.setAdapter(adapter);

        // Get logged-in user's ID
        userId = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid()
                : null;

        if (userId != null) {
            databaseReference = FirebaseDatabase.getInstance().getReference("Medicines").child(userId);
            attachDatabaseListener();  // Attach real-time listener
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            Log.e("TodayAlarmActivity", "User ID is null");
        }
    }

    private void attachDatabaseListener() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String todayDate = sdf.format(new Date()); // Get today's date

        databaseReference.addChildEventListener(new com.google.firebase.database.ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, String previousChildName) {
                String medicineName = dataSnapshot.child("name").getValue(String.class);
                String schedule = dataSnapshot.child("schedule").getValue(String.class);
                String dateAdded = dataSnapshot.child("dateAdded").getValue(String.class);

                if (medicineName != null && dateAdded != null && dateAdded.equals(todayDate)) {
                    medicineList.add(medicineName + " - " + schedule);
                    adapter.notifyDataSetChanged();
                    Log.d("TodayAlarmActivity", "Medicine added: " + medicineName);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, String previousChildName) {
                // Medicine updated - find and update it
                String updatedMedicineName = dataSnapshot.child("name").getValue(String.class);
                String updatedSchedule = dataSnapshot.child("schedule").getValue(String.class);
                String updatedDateAdded = dataSnapshot.child("dateAdded").getValue(String.class);

                if (updatedMedicineName != null && updatedDateAdded != null && updatedDateAdded.equals(todayDate)) {
                    for (int i = 0; i < medicineList.size(); i++) {
                        if (medicineList.get(i).contains(updatedMedicineName)) {
                            medicineList.set(i, updatedMedicineName + " - " + updatedSchedule);
                            adapter.notifyDataSetChanged(); // Update only changed item
                            Log.d("TodayAlarmActivity", "Medicine updated: " + updatedMedicineName);
                            break;
                        }
                    }
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                // Medicine removed - find and delete it
                String removedMedicineName = dataSnapshot.child("name").getValue(String.class);
                if (removedMedicineName != null) {
                    medicineList.removeIf(item -> item.contains(removedMedicineName));
                    adapter.notifyDataSetChanged(); // Update only removed item
                    Log.d("TodayAlarmActivity", "Medicine removed: " + removedMedicineName);
                }
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, String previousChildName) {
                // Not needed in this scenario
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", "Error fetching medicines: " + error.getMessage());
                Toast.makeText(TodayAlarmActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
