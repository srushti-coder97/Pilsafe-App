package com.example.signuplogin; // Ensure the correct package name

import java.util.List;

public class AlarmModel {
    private String id;
    private String medicineName;
    private List<String> reminderTimesList;
    private String date;

    // Empty constructor for Firebase
    public AlarmModel() {
    }

    // Constructor with four parameters
    public AlarmModel(String id, String medicineName, List<String> reminderTimesList, String date) {
        this.id = id;
        this.medicineName = medicineName;
        this.reminderTimesList = reminderTimesList;
        this.date = date;
    }

    // ✅ Getter methods
    public String getId() {
        return id;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public List<String> getReminderTimesList() {
        return reminderTimesList;
    }

    public String getDate() {
        return date;
    }

    // ✅ Setter methods (optional, only needed if modifying data)
    public void setId(String id) {
        this.id = id;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public void setReminderTimesList(List<String> reminderTimesList) {
        this.reminderTimesList = reminderTimesList;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
