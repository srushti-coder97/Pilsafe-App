package com.example.signuplogin;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;

public class YesReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String medicineName = intent.getStringExtra("medicine_name");

        if (medicineName != null) {
            // Store in Firebase
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("MedicationRecords");
            String recordId = databaseReference.push().getKey();
            HashMap<String, Object> record = new HashMap<>();
            record.put("medicineName", medicineName);
            record.put("status", "Taken");
            record.put("timestamp", System.currentTimeMillis());

            if (recordId != null) {
                databaseReference.child(recordId).setValue(record)
                        .addOnSuccessListener(aVoid -> Log.d("YesReceiver", "Medicine recorded as taken"))
                        .addOnFailureListener(e -> Log.e("YesReceiver", "Failed to store data", e));
            }

            // Open MedicationActivity
            Intent activityIntent = new Intent(context, MedicationsFragment.class);
            activityIntent.putExtra("medicine_name", medicineName);
            activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(activityIntent);
        }
    }
}