package com.example.signuplogin;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditProfileActivity extends AppCompatActivity {

    private EditText editName, editEmail, editPhone, editGender, editBirthdate, editBloodGroup, editAge;
    private Button saveProfileButton;
    private ImageView editProfileImageView;

    private DatabaseReference userRef;
    private FirebaseAuth mAuth;
    private static final String TAG = "EditProfileActivity";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "User not logged in!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String userId = currentUser.getUid();
        userRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Initialize Views
        editProfileImageView = findViewById(R.id.editProfileImageView);
        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editPhone = findViewById(R.id.editPhone);
        editGender = findViewById(R.id.editGender);
        editBirthdate = findViewById(R.id.editBirthdate);
        editBloodGroup = findViewById(R.id.editBloodGroup);
        editAge = findViewById(R.id.editAge);
        saveProfileButton = findViewById(R.id.saveProfileButton);

        // Load existing user data
        loadUserData();

        // Birthdate Picker
        editBirthdate.setOnClickListener(v -> showDatePicker());

        // Save Button Click
        saveProfileButton.setOnClickListener(v -> saveUserData());
    }

    private void loadUserData() {
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    editName.setText(snapshot.child("name").getValue(String.class));
                    editEmail.setText(snapshot.child("email").getValue(String.class));
                    editPhone.setText(snapshot.child("phone").getValue(String.class));
                    editGender.setText(snapshot.child("gender").getValue(String.class));
                    editBirthdate.setText(snapshot.child("birthdate").getValue(String.class));
                    editBloodGroup.setText(snapshot.child("bloodGroup").getValue(String.class));
                    editAge.setText(snapshot.child("age").getValue(String.class));
                } else {
                    Log.e(TAG, "User data does not exist");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(EditProfileActivity.this, "Failed to load profile", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Database error: " + error.getMessage());
            }
        });
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year1, month1, dayOfMonth) -> {
                    String selectedDate = year1 + "-" + (month1 + 1) + "-" + dayOfMonth;
                    editBirthdate.setText(selectedDate);
                },
                year, month, day
        );
        datePickerDialog.show();
    }

    private void saveUserData() {
        String name = editName.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String gender = editGender.getText().toString().trim();
        String birthdate = editBirthdate.getText().toString().trim();
        String bloodGroup = editBloodGroup.getText().toString().trim();
        String age = editAge.getText().toString().trim();

        if (name.isEmpty() || phone.isEmpty() || gender.isEmpty() || birthdate.isEmpty() || bloodGroup.isEmpty() || age.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        if (phone.length() < 10) {
            Toast.makeText(this, "Enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }


        Map<String, Object> userUpdates = new HashMap<>();
        userUpdates.put("name", name);
        userUpdates.put("phone", phone);
        userUpdates.put("gender", gender);
        userUpdates.put("birthdate", birthdate);
        userUpdates.put("bloodGroup", bloodGroup);
        userUpdates.put("age", age);

        userRef.updateChildren(userUpdates).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(EditProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                finish();
            } else {

                Toast.makeText(EditProfileActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Profile update failed");


            }
        });
    }
}
