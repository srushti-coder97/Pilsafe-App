package com.example.signuplogin;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class MedicineAdapter extends RecyclerView.Adapter<MedicineAdapter.MedicineViewHolder> {

    private List<Medicine> medicineList;
    private Context context;

    public MedicineAdapter(Context context, List<Medicine> medicineList) {
        this.context = context;
        this.medicineList = medicineList;
    }

    @NonNull
    @Override
    public MedicineViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medicine, parent, false);
        return new MedicineViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicineViewHolder holder, int position) {
        Medicine medicine = medicineList.get(position);

        holder.medicineName.setText(medicine.getName());
        holder.description.setText(medicine.getDescription());
        holder.shape.setText(medicine.getShape());
        holder.schedule.setText(medicine.getSchedule());
        holder.reminderType.setText(medicine.getReminderType());

        // Convert List<String> to a single string for display
        holder.reminderTimes.setText(TextUtils.join(", ", medicine.getReminderTimes()));

        holder.date.setText(medicine.getDateAdded());

        // Handle delete button click
        holder.btnDelete.setOnClickListener(view -> deleteMedicine(position));
    }

    @Override
    public int getItemCount() {
        return medicineList.size();
    }

    public static class MedicineViewHolder extends RecyclerView.ViewHolder {
        TextView medicineName, description, shape, schedule, reminderType, reminderTimes, date;
        ImageView btnDelete; // Delete button

        public MedicineViewHolder(@NonNull View itemView) {
            super(itemView);
            medicineName = itemView.findViewById(R.id.medicineName);
            description = itemView.findViewById(R.id.description);
            shape = itemView.findViewById(R.id.shape);
            schedule = itemView.findViewById(R.id.schedule);
            reminderType = itemView.findViewById(R.id.reminderType);
            reminderTimes = itemView.findViewById(R.id.reminderTimes);
            date = itemView.findViewById(R.id.date);
            btnDelete = itemView.findViewById(R.id.btnDeleteMedicine); // Reference delete button
        }
    }

    // Delete medicine from Firebase and RecyclerView
    private void deleteMedicine(int position) {
        if (position < 0 || position >= medicineList.size()) {
            return; // Prevent out-of-bounds crash
        }

        Medicine medicine = medicineList.get(position);
        if (medicine == null || medicine.getMedicineId() == null || medicine.getMedicineId().isEmpty()) {
            Toast.makeText(context, "Error: Invalid medicine ID", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get User ID for Firebase path
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Users")  // If medicines are stored under users
                .child(userId)
                .child("Medicines")
                .child(medicine.getMedicineId()); // Use getMedicineId() instead of getId()

        ref.removeValue().addOnSuccessListener(unused -> {
            medicineList.remove(position);  // Remove from local list
            notifyItemRemoved(position);   // Notify RecyclerView
            notifyItemRangeChanged(position, medicineList.size()); // Fix index issues
            Toast.makeText(context, "Medicine deleted", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e ->
                Toast.makeText(context, "Failed to delete: " + e.getMessage(), Toast.LENGTH_SHORT).show()
        );
    }
}
